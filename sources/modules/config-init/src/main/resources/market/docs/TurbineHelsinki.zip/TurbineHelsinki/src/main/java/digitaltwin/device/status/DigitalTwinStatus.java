/**
 * Copyright Indra Sistemas, S.A.
 * 2013-2018 SPAIN
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package digitaltwin.device.status;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.minsait.onesait.platform.digitaltwin.status.IDigitalTwinStatus;
import com.minsait.onesait.platform.digitaltwin.property.controller.OperationType;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DigitalTwinStatus implements IDigitalTwinStatus{
	
		@Getter
		@Setter
		private Integer rotorSpeed;
		@Getter
		@Setter
		private OperationType operationRotorSpeed;
		@Getter
		@Setter
		private Integer maxRotorSpeed;
		@Getter
		@Setter
		private OperationType operationMaxRotorSpeed;
		@Getter
		@Setter
		private Double nacelleTemp;
		@Getter
		@Setter
		private OperationType operationNacelleTemp;
		@Getter
		@Setter
		private Integer windDirection;
		@Getter
		@Setter
		private OperationType operationWindDirection;
		@Getter
		@Setter
		private Double alternatorTemp;
		@Getter
		@Setter
		private OperationType operationAlternatorTemp;
		@Getter
		@Setter
		private Double power;
		@Getter
		@Setter
		private OperationType operationPower;
	
	private Map<String, Class> mapClass;

	@PostConstruct
	public void init() {
		//Init Operation types values
			setOperationRotorSpeed(OperationType.OUT);
			setOperationMaxRotorSpeed(OperationType.IN_OUT);
			setOperationNacelleTemp(OperationType.OUT);
			setOperationWindDirection(OperationType.OUT);
			setOperationAlternatorTemp(OperationType.OUT);
			setOperationPower(OperationType.OUT);
		
		mapClass = new HashMap<String, Class>();
			mapClass.put("rotorSpeed", Integer.class);
			mapClass.put("maxRotorSpeed", Integer.class);
			mapClass.put("nacelleTemp", Double.class);
			mapClass.put("windDirection", Integer.class);
			mapClass.put("alternatorTemp", Double.class);
			mapClass.put("power", Double.class);
	}

	@Override
	public Boolean validate(OperationType operationType, String property) {
		try {
			Class cls = Class.forName(DigitalTwinStatus.class.getName());
			Method method = cls.getDeclaredMethod("getOperation"+property.substring(0, 1).toUpperCase() + property.substring(1), null);
			OperationType operation = (OperationType) method.invoke(this,null);
			
			if(operation.equals(operationType) || operation.equals(OperationType.IN_OUT)) {
				return true;
			}
			return false;
		}catch (Exception e) {
			log.error("Validation of property "+ property + " failed.", e);
			return false;
		} 
	}

	@Override
	public Object getProperty(String property) {
		try {
			Class cls = Class.forName(DigitalTwinStatus.class.getName());
			Method method = cls.getMethod("get"+property.substring(0, 1).toUpperCase() + property.substring(1), null);
			
			return method.invoke(this, new Class[]{});

		}catch (Exception e) {
			log.error("get property "+ property + " failed.", e);
			return null;
		} 
	}

	@Override
	public void setProperty(String property, Object value) {
		try {
			Class cls = Class.forName(DigitalTwinStatus.class.getName());
			
			Method method = cls.getMethod("set"+property.substring(0, 1).toUpperCase() + property.substring(1), mapClass.get(property));
			method.invoke(this, mapClass.get(property).cast(value));

		}catch (Exception e) {
			log.error("set property "+ property + " failed.", e);
		} 
		
	}
	
	@Override
	public Map<String, Object> toMap() {
		Map<String, Object> properties = new HashMap<String, Object>();
		
			properties.put("rotorSpeed",rotorSpeed);
			properties.put("maxRotorSpeed",maxRotorSpeed);
			properties.put("nacelleTemp",nacelleTemp);
			properties.put("windDirection",windDirection);
			properties.put("alternatorTemp",alternatorTemp);
			properties.put("power",power);
		
		return properties;
	}
	
}
