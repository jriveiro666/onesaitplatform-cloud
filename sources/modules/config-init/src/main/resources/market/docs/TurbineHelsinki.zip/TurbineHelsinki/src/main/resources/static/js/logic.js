var digitalTwinApi = Java.type('com.indracompany.sofia2.digitaltwin.logic.api.DigitalTwinApi').getInstance();
function init(){
    digitalTwinApi.log('Init TurbineHelsinki shadow');
    digitalTwinApi.setStatusValue('alternatorTemp', 25.0);
    digitalTwinApi.setStatusValue('power', 50000.2);
    digitalTwinApi.setStatusValue('nacelleTemp', 25.9);
    digitalTwinApi.setStatusValue('rotorSpeed', 30);
    digitalTwinApi.setStatusValue('windDirection', 68);

    digitalTwinApi.sendUpdateShadow();
    digitalTwinApi.log('Send Update Shadow for init function');
}
function main(){
    digitalTwinApi.log('New loop');
    var alternatorTemp = digitalTwinApi.getStatusValue('alternatorTemp');

    alternatorTemp ++;
    digitalTwinApi.setStatusValue('alternatorTemp', alternatorTemp);
    digitalTwinApi.setStatusValue('power', 50000.2);
    digitalTwinApi.setStatusValue('nacelleTemp', 25.9);
    digitalTwinApi.setStatusValue('rotorSpeed', 30);
    digitalTwinApi.setStatusValue('windDirection', 68);

    digitalTwinApi.sendUpdateShadow();
    digitalTwinApi.log('Send Update Shadow');
 
   if(alternatorTemp>=30){
      digitalTwinApi.sendCustomEvent('tempAlert');
   }
}

var onActionConnectElectricNetwork=function(data){ }
var onActionDisconnectElectricNetwork=function(data){ }
var onActionLimitRotorSpeed=function(data){ }
